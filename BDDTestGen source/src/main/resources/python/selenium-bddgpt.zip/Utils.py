def file_to_string(file_name: str):
    with open(file_name, "r", encoding="utf-8") as input_file:
        return "".join(input_file.readlines())


def string_to_file(file_name: str, string: str):
    with open(file_name, "w", encoding="utf-8") as output_file:
        output_file.write(string)
