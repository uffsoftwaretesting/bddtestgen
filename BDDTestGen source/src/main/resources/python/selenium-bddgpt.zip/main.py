import Utils
import funcoes
from funcoes import run_like_chat, extract_json
from GptAgent import GptAgent
import os
import json


def main():
    os.environ['OPENAI_API_KEY'] = Utils.file_to_string('key.txt')
    gpt = GptAgent()
    input_string = funcoes.extrair_identificadores('input.json')
    output_puro = run_like_chat(gpt, input_string, 'gpt-4o')
    Utils.string_to_file('output_original.txt', output_puro)

    output_string = extract_json(output_puro)
    with open('output.json', 'w') as file:
        json.dump(json.loads(output_string), file, indent=4)


if __name__ == "__main__":
    main()
