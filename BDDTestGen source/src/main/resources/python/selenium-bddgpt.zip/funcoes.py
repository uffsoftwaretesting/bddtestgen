import Utils
from GptAgent import GptAgent
import json
import re
from jsmin import jsmin


def run_like_chat(agent: GptAgent, string_input: str, model, temp=1) -> str:
    messages = [string_input, Utils.file_to_string("explicacao_gpt.txt")]
    for message in messages:
        role = "user"
        agent.add_message(role=role, content=message)
    while True:
        try:
            print(f"agent running")
            agent.run(model=model, temperature=temp, save_response_to_message=True)
            response_content = agent.last_response.content
            print(f"Response added to output")
            break
        except Exception as e:
            print("Run failed. Trying again")
    return response_content


def extrair_identificadores(arquivo):
    with open(arquivo, 'r') as f:
        dados = json.load(f)

    identificadores = [item['identifier_tracking'] for item in dados]

    return ', '.join(identificadores)


def extract_json(input_str):
    start = input_str.find("{")
    end = input_str.rfind("}") + 1
    if start != -1 and end != -1:
        json_str = input_str[start:end]
        return jsmin(json_str)
    return ""
